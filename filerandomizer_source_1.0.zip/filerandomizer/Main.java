
import filerandomizer.FileRandomizer;
import filerandomizer.GUI;

/*
 * Author:          Daniel Ward
 * Date Created:    4/11/10
 * Email:           dwa012@gmail.com
 */
public class Main
{
    private static FileRandomizer test;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        new GUI();
    }

}
