/*
 * Author:          Daniel Ward
 * Date Created:    4/11/10
 * Email:           dwa012@gmail.com
 */

package filerandomizer;

//The packages that are need for the GUI
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI extends JFrame
{
    //global text area to print to
    private JTextArea textDisplay = new JTextArea();

    /**
     * creates the main menu gui and shows the new frame
     */
    public GUI()
    {
        super();

        //main menu buttons, text area , and panel
        JButton chooseDirButton = new JButton("Choose Directory");
        JButton chooseFileButton = new JButton("Choose File(s)");
        JScrollPane scrollDisplay = new JScrollPane(textDisplay);

        JPanel panel = new JPanel();

        //set attributes of the frame
        this.setTitle("File Randomizer");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setMinimumSize(new java.awt.Dimension(600, 450));
        this.setResizable(false);
        

        //create the gloabal panels
        JPanel topPanel = new JPanel();
        JPanel bottomPanel = new JPanel();
        JPanel buttonPanel = new JPanel();
        //set main menu layout and add panels
        panel.setLayout(new BorderLayout());
        panel.setBackground(Color.white);
        panel.add(topPanel,BorderLayout.CENTER);
        panel.add(buttonPanel,BorderLayout.SOUTH);

        //topPanel atrributes
        topPanel.setPreferredSize(new Dimension(600, 360));
        topPanel.setMaximumSize(new Dimension(600, 360));
        
        //set bottomPanel Layout
        //buttonPanel.setLayout(new CardLayout());
        

        //set backgorund of panels to white
        topPanel.setBackground(Color.white);
        buttonPanel.setBackground(Color.white);


        //add buttons to the panel
        buttonPanel.add(chooseDirButton);
        buttonPanel.add(chooseFileButton);
        scrollDisplay.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollDisplay.setPreferredSize(new Dimension(600, 360));
        textDisplay.setEditable(false);
        textDisplay.setLineWrap(true);
        textDisplay.setWrapStyleWord(true);

        scrollDisplay.validate();

        //add header to the headerPanel
        topPanel.add(scrollDisplay);


        //add the panels to the main panels
        //bottomPanel.add(buttonPanel);

        //action methods for the buttons
        chooseDirButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    java.io.File[] files = openDirectory();

                    if(files != null)
                    {
                        JOptionPane pane = new JOptionPane("Select an Operation to perform");
                        String[] options = {"Add Tag","Rename","Copy then Add Tag"};
                        pane.setOptions(options);
                        JDialog dialog = pane.createDialog(new JFrame(), "What to do?");
                        dialog.setVisible(true);
                        performOperation(pane.getValue(),files);
                    }
                }

                private void performOperation(Object obj,java.io.File[] files)
                {
                    if(obj != null)
                    {
                        String temp = (String)obj;
                        if(temp.equals("Add Tag"))
                            addTag(files);
                        if(temp.equals("Rename"))
                            renameFile(files);
                        if(temp.equals("Copy then Add Tag"))
                            copyAndTag(files);
                    }
                }
            });

        chooseFileButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    java.io.File[] files = openFiles();
                    if(files != null)
                    {
                        JOptionPane pane = new JOptionPane("Select an Operation to perform");
                        String[] options = {"Add Tag","Rename","Copy then Add Tag"};
                        pane.setOptions(options);
                        JDialog dialog = pane.createDialog(new JFrame(), "What to do?");
                        dialog.setVisible(true);
                        performOperation(pane.getValue(),files);
                    }
                }

                private void performOperation(Object obj,java.io.File[] files)
                {
                    if(obj != null)
                    {
                        String temp = (String)obj;
                        if(temp.equals("Add Tag"))
                            addTag(files);
                        if(temp.equals("Rename"))
                            renameFile(files);
                        if(temp.equals("Copy then Add Tag"))
                            copyAndTag(files);
                    }
                }
            });


        this.add(panel);
        pack();

        this.setLocationByPlatform(true);
        this.setVisible(true);
    }

    private void print(String text)
    {
        textDisplay.append(text);
        textDisplay.setCaretPosition(textDisplay.getDocument().getLength());
    }

    private java.io.File[] openDirectory()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(fileChooser.showOpenDialog(GUI.this) == JFileChooser.APPROVE_OPTION)
            return fileChooser.getSelectedFile().listFiles();
        else
            return null;
    }

    private java.io.File[] openFiles()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setMultiSelectionEnabled(true);
        if(fileChooser.showOpenDialog(GUI.this) == JFileChooser.APPROVE_OPTION)
            return fileChooser.getSelectedFiles();
        else
            return null;
    }

    private void renameFile(java.io.File[] file)
    {
        final Progress bar = new Progress(file.length);
        final java.io.File[] files = file;

        Runnable thread = new Runnable()
        {
            public void run()
            {
                for(int i = 0; i < files.length; i++)
                {
                    String temp = "";
                    temp = FileRandomizer.rename(files[i]);
                    print(" Renamed File:\n From\n "+files[i].getPath()+"\n To\n "+ temp+"\n\n");
                    textDisplay.repaint();
                    bar.advance();
                }
            }
        };

        new Thread(thread).start();
        
    }

    private void addTag(java.io.File[] file)
    {
        final Progress bar = new Progress(file.length);
        final java.io.File[] files = file;
        
        Runnable thread = new Runnable()
        {
            public void run()
            {
                for(int i = 0; i < files.length; i++)
                {
                    String temp = "";
                    temp = FileRandomizer.addTag(files[i]);
                    print(" Renamed File:\n From\n "+files[i].getPath()+"\n To\n "+ temp+"\n\n");
                    textDisplay.repaint();
                    bar.advance();
                }
            }
        };
        
        new Thread(thread).start();
    }

    private void copyAndTag(java.io.File[] file)
    {
        
        new JOptionPane().showMessageDialog(GUI.this,"Select an output directory");
        final JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if(fileChooser.showOpenDialog(GUI.this) == JFileChooser.APPROVE_OPTION)
        {
            final Progress bar = new Progress(file.length);
            final java.io.File[] files = file;
        
            Runnable thread = new Runnable()
            {
                public void run()
                {
                    java.io.File dest = fileChooser.getSelectedFile();
                    for(int i = 0; i < files.length; i++)
                    {
                        String temp = "";
                        temp = FileRandomizer.copyAndTag(files[i],dest);
                        print("Copied File:\nFrom\n"+files[i].getPath()+"\nTo\n"+ temp+"\n\n");
                        textDisplay.repaint();
                        bar.advance();
                    }
                }
            };
            
            new Thread(thread).start();
        }
    }

    private class Progress
    {
        private JFrame frame = new JFrame("Progress");
        private javax.swing.JProgressBar bar;
        private int position;
        private int length;

        public Progress(int length)
        {
            this.length = length;
            position = 0;
            bar = new javax.swing.JProgressBar(0,length);
            frame.setMinimumSize(new java.awt.Dimension(200, 65));
            frame.setResizable(false);
            JPanel pane = new JPanel();
            pane.setLayout(new java.awt.FlowLayout());
            pane.setBackground(Color.white);
            bar.setValue(0);
            bar.setStringPainted(true);
            pane.add(bar);
            frame.setContentPane(pane);
            frame.setLocationByPlatform(true);
            frame.setVisible(true);
        }

        public void advance()
        {
            position = position + 1;
            bar.setValue(position);
            bar.repaint();
            if(position == length)
            {
                try
                {
                    Thread.sleep(500);
                    frame.dispose();
                }
                catch (InterruptedException e){}
            }
        }
    }

}
