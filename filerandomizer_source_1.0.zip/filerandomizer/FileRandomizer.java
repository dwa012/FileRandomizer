/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package filerandomizer;

import java.io.IOException;
import java.io.File;
import java.io.StringWriter;

/*
 * Author:          Daniel Ward
 * Date Created:    4/11/10
 * Email:           dwa012@gmail.com
 */
public class FileRandomizer
{
    public FileRandomizer()
    {
        //left blank
    }

    public static String rename(File file)
    {
        StringWriter buf = new StringWriter(30);
        buf.append(file.getParent());
        if(file.getParent().charAt(file.getParent().length()-1) != File.separatorChar)
            buf.append(File.separatorChar);
        buf.append(randomName(4));
        buf.append(getExt(file.getName()));
        String temp = buf.toString();
        file.renameTo(new File(temp));
        return temp;
    }
    
    public static String copyAndTag(File src,File dst)
    {
        StringWriter buf = new StringWriter();
        buf.append(dst.getPath());
        buf.append(File.separatorChar);
        buf.append(randomName(4));
        buf.append("_");
        buf.append(src.getName());
        String temp = buf.toString();
        try
        {
            copyFile(src,new File(temp));
        }
        catch(IOException e)
        {
            temp = "\n**Error creating file\n**";
        }
        return temp;
    }

    public static String addTag(File file)
    {
        StringWriter buf = new StringWriter(30);
        buf.append(file.getParent());
        if(file.getParent().charAt(file.getParent().length()-1) != File.separatorChar)
            buf.append(File.separatorChar);
        buf.append(randomName(4));
        buf.append("_");
        buf.append(file.getName());
        String temp = buf.toString();
        file.renameTo(new File(temp));
        return temp;
    }

    private static String randomName(int length)
    {
        java.io.StringWriter result = new java.io.StringWriter();

        for(int i = 0; i < length; i++)
            result.append(randomChar());

        return result.toString();
    }
    
    private static char randomChar()
    {
        char result = '\0';

        while(result == '\0')
        {
            double random = Math.random()*100;
            random = random % 150;
            char temp = (char)random;

            if(temp >= '0' && temp <= '9')
                result = temp;
            else if(temp >= 'a' && temp <= 'z')
                result = temp;
            else if(temp >= 'A' && temp <= 'Z')
                result = temp;
            else
                result = '\0';
        }

        return result;
    }

    private static String getExt(String name)
    {
        String result = ".";
        String split[] = name.split("\\.");
        result = result + split[1];
        return result;
    }

    /**
     * 
     * code copied from: 
     * http://www.exampledepot.com/egs/java.io/CopyFile.html
     * @param file
     * @param dst
     * @throws java.io.IOException
     */
    private static void copyFile(File src, File dst) throws java.io.IOException
    {
        java.io.InputStream in = new java.io.FileInputStream(src);
        java.io.OutputStream out = new java.io.FileOutputStream(dst);

        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }
}
